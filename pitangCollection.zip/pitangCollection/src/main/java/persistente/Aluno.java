package persistente;

public class Aluno extends ObjetoPersistenteAbstrato {
}
