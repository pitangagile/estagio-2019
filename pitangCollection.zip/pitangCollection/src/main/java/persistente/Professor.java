package persistente;

public class Professor extends ObjetoPersistenteAbstrato {

    @Override
    public Boolean salvar() {
        return super.salvar();
    }
}
