package kagglestudents;

import java.util.List;

public interface IExtractStudent {

    public List<StudentVO> load();
}
