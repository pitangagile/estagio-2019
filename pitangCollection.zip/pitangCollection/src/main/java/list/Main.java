package list;

public class Main {
    public static void main(String... args) {
        PitangListGenerica<Integer> pitangListGenerica = new PitangListGenerica<Integer>();
        System.out.println(pitangListGenerica.size());
    }


}
